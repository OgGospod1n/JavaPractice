package com.example.shablon14;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import java.util.ArrayList;
import java.util.List;

@RequestMapping("/home/Student")
@Controller
public class StudentController {
    List<Student> list = new ArrayList<>();
    @GetMapping("/add")
    public String add(@RequestParam String firstName, @RequestParam String lastName, @RequestParam String middleName, Model bridge){
        list.add(new Student(firstName, lastName, middleName));
        bridge.addAttribute("firstName", firstName);
        bridge.addAttribute("lastName", lastName);
        bridge.addAttribute("middleName", middleName);
        return "Student";
    }
    @GetMapping("/{last}")
    public String get(@PathVariable String last, Model bridge){
        boolean is = true;
        for(int i=0; i<list.size(); i++){
            if(list.get(i).getFirstName().equals(last)){
                bridge.addAttribute("firstName", list.get(i).getFirstName());
                bridge.addAttribute("lastName", list.get(i).getLastName());
                bridge.addAttribute("middleName", list.get(i).getMiddleName());
                is = false;
                break;
            }
        }
        if (is)
            bridge.addAttribute("firstName", "Not found");
        return "Student";
    }
    @GetMapping("/del/{last}")
    public String delete(@PathVariable String last, Model bridge){
        boolean is = true;
        for(int i=0; i<list.size(); i++){
            if(list.get(i).getFirstName().equals(last)){
                bridge.addAttribute("name", list.get(i).getFirstName());
                bridge.addAttribute("creationDate", list.get(i).getLastName());
                bridge.addAttribute("price", list.get(i).getMiddleName());
                is = false;
                list.remove(i);
                break;
            }
        }
        if (is)
            bridge.addAttribute("firstName", "Not found");
        return "Student";
    }
}
