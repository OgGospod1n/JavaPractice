package com.example.shablon14;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.ArrayList;
import java.util.List;

@RequestMapping("/home/Group")
@Controller
public class GroupController {
    List<Group> list = new ArrayList<>();
    @GetMapping("/add")
    public String add(@RequestParam String groupName, Model bridge){
        list.add(new Group(groupName));
        bridge.addAttribute("groupName", groupName);
        return "Group";
    }
    @GetMapping("/{name}")
    public String get(@PathVariable String groupName, Model bridge){
        boolean is = true;
        for(int i=0; i<list.size(); i++){
            if(list.get(i).getGroupName().equals(groupName)){
                bridge.addAttribute("groupName", list.get(i).getGroupName());
                is = false;
                break;
            }
        }
        if (is)
            bridge.addAttribute("groupName", "Not found");
        return "Group";
    }
    @GetMapping("/del/{name}")
    public String delete(@PathVariable String groupName, Model bridge){
        boolean is = true;
        for(int i=0; i<list.size(); i++){
            if(list.get(i).getGroupName().equals(groupName)){
                bridge.addAttribute("groupName", list.get(i).getGroupName());
                is = false;
                list.remove(i);
                break;
            }
        }
        if (is)
            bridge.addAttribute("groupName", "Not found");
        return "groupName";
    }
}