package com.example.shablon14;


import lombok.Getter;
import lombok.Setter;


//@Getter
//@Setter
public class Group {
    private String groupName;
    public Group(String groupName){
        this.groupName = groupName;
    }

    public String getGroupName() {
        return groupName;
    }

    public void setGroupName(String groupName) {
        this.groupName = groupName;
    }
}
