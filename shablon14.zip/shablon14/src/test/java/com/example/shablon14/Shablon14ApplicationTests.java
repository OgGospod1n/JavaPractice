package com.example.shablon14;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Shablon14ApplicationTests {

    @Test
    void contextLoads() {
    }

}
